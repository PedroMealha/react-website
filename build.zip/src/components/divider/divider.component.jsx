import './divider.styles.scss';

const Divider = () =>
	<div className="divider"></div>

export default Divider;