export const STACKS_ACTION_TYPES = {
	SET_STACKS: "stack/SET_STACKS",
};