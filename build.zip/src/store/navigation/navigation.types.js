export const NAV_ACTION_TYPES = {
  SET_CURRENT_NAV: "navigation/SET_CURRENT_NAV",
};